#include <stdio.h>
int main()
{
   /* https://c.runoob.com/compile/11/ */
   /*Write C code in this online editor and run it. */
   
	int NUM1[5]={3,-17,27,-12,322};
	int i,sum=0;
	for (i=0;i<5;i++)
		sum=sum+NUM1[i];
	printf("The Result is:%d \n",sum);
	return 0;
}
		
		
  
 
  
 